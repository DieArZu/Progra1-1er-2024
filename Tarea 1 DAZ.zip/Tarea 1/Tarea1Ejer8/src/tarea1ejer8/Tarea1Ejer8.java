/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer8;

import java.util.Scanner;

/**
 *8.	Crear una aplicación en JAVA que Imprimir los números entre el 10 
 * y el 35, saltando de tres en tres.
 * @author diego
 */
public class Tarea1Ejer8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        int contador = 10;
        int sumando=7;
        int suma=0;
        //int max=1;
          
          // Scanner dato = new Scanner( System.in); 
          // System.out.print("Ingrese el N o limite de sumatoria ");
           // max = dato.nextInt();
          
            while (sumando < 34 )
        {
            sumando=sumando+3;
            suma=suma+sumando;
            System.out.println(sumando);
        
        
        }
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
