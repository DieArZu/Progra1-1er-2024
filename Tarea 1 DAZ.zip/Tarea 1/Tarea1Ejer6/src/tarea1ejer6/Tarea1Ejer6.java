/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer6;

import java.util.Scanner;

/**
 *6.	Crear una aplicación de JAVA donde se debe de ingresar un  número  natural N se  desea 
 * calcular  la suma de los números naturales anteriores a  N, es decir, desde 1 hasta
 * n ejemplo: Si N= 5 => suma=1+2+3+4+5=15.
 * @author diego
 */
public class Tarea1Ejer6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
          int contador = 1;
          int sumando=0;
          int suma=0;
          int max=1;
          
           Scanner dato = new Scanner( System.in); 
           System.out.print("Ingrese el N o limite de sumatoria ");
            max = dato.nextInt();
          
            while (contador < max+1 )
        {
            sumando=sumando+1;
            suma=suma+sumando;
            contador=contador+1;
            System.out.println(sumando+" ---> "+suma);
        
        
        }
        
        
        
        
        
    }
    
}
