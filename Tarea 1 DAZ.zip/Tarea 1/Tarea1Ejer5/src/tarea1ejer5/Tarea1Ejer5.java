/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer5;

import java.util.Scanner;

/**
 *5.	Crear una aplicación en JAVA para una tienda que planea ofrecer a los clientes un descuento que dependerá 
 * del tipo de membrecia que tiene se debe de ingresar el tipo.   Si la membrecia es de TIPO A se  les  dará  un
 * 10% de descuento sobre el total de la compra; TIPO B   se   le   otorga   un   20%   de descuento; y  si  son 
 * TIPO C  se  les  da  un 40%  de descuento. 
 
 */
public class Tarea1Ejer5 {


    public static void main(String[] args) {
    
        float subtotal;
        float datdescA;
        float datdescB;
        float datdescC;
        float total;
        float suma=1;
        float sumaA=1;
        float sumaB=1;
        float sumaC=1;
        float sumandoA=0;
        float sumandoB=0;
        float sumandoC=0;
        int tipo;
        
        
        Scanner dato = new Scanner( System.in);
        
        
            while ( suma > 0)
            {
            System.out.print("Ingrese el costo del producto o 0 para terminar ");
            suma = dato.nextFloat();
            System.out.print("Ingrese el tipo de mercaderia:\n 1 para tipoA \n 2 para tipoB \n 3 para tipoC \n");
            tipo = dato.nextInt();
                                               
                
            if( tipo == 1)
                    {
                    sumandoA = suma+sumandoA;
                    }
              
            else if( tipo == 2)
                {
                  sumandoB = suma + sumandoB;
                }
                        
                    
            else if( tipo == 3)
            {
                sumandoC = suma + sumandoC;
            }
             
            }
        
            
        //System.out.println(sumandoA);
      //  System.out.println(sumandoB);
       // System.out.println(sumandoC);
        datdescA = (float) (sumandoA*0.10);
        datdescB = (float) (sumandoB*0.20);
        datdescC = (float) (sumandoC*0.4);
            
            
        System.out.println("SubTotal Productos A "+sumandoA);
        System.out.println("SubTotal Productos B "+sumandoB);
        System.out.println("SubTotal Productos C "+sumandoC);
        System.out.println("Descuento Productos A "+datdescA);
        System.out.println("Descuento Productos B "+datdescB);
        System.out.println("Descuento Productos C "+datdescC);
        System.out.println("Total Productos A "+(sumandoA-datdescA));
        System.out.println("Total Productos B "+(sumandoB-datdescB));
        System.out.println("Total Productos C "+(sumandoC-datdescC));
        System.out.println("Gran Total: "+((sumandoA-datdescA)+(sumandoB-datdescB)+(sumandoC-datdescC)));
   
            
    }
    
}
