/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer10;

import java.util.Scanner;

/**
 *10.	Escribir un programa en JAVA que pregunte al usuario una cantidad a 
 * invertir, el interés anual y el número de años que desea invertir, y muestre
 * por pantalla el capital obtenido en la inversión cada año que dura la 
 * inversión.
 * @author diego
 */
public class Tarea1Ejer10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float monto=0;
        float interes=0;
        float interesesaco=0;
        float years=0;
        float capital;
        int veces=0;
        float interesanual;
        
        
        Scanner dato = new Scanner( System.in); 
        System.out.print("Ingrese monto a invertir: ");
        monto = dato.nextFloat(); 
        System.out.print("Ingrese interes anual: ");
        interes = dato.nextFloat(); 
        System.out.print("Ingrese los year: ");
        years = dato.nextFloat(); 
        
      
     
        while(veces<= years-1)
        {
            veces++;
            interesanual = interes*monto; 
            interesesaco=monto*(interes/100)*veces;
            System.out.println("Year "+ veces);
            System.out.println("Intereses al final year "+veces+" es de"+ interesesaco);
            System.out.println("Monto final al final year : "+ (monto+interesesaco));
            
            
            
        }
        
        
    }
    
}
