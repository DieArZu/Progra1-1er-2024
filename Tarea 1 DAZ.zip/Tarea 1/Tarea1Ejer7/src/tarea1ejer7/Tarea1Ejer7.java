/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer7;

import java.util.Scanner;

/**
 *7.	Crear una aplicación en JAVA que le pregunte al usuario cuántos
 * números se van a introducir por teclado por ejemplo 10 numeros, pida esos
 * números y escriba cuántos negativos ha introducido y cuantos positivos.
 * @author diego
 */
public class Tarea1Ejer7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        int vecespar=0;
        int vecesimpar=0;
        int veces;
        int contador = 1;
        int valor;
        
        Scanner dato = new Scanner (System.in);  
        System.out.print("Ingrese la cantidad de datos a clasificar:  ");
         veces = dato.nextInt(); 
                                           
                
        while ( contador <= veces) 
            {
            contador=contador+1;
            System.out.print("Ingrese el primer numero ");
            valor = dato.nextInt();                                              
                
            if( valor%2 == 0)
                    {
                    vecespar=vecespar+1;
                    }
              
            else if( valor % 2 != 0)
                {
                  vecesimpar= vecesimpar+1;
                }
                        
                    
            }
        
        System.out.println("Cantidad de Pares: "+vecespar);
        System.out.println("Cantidad de imPares: "+vecesimpar);
    }
    
}
