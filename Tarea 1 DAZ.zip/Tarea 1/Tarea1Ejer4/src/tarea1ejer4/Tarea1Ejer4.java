/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer4;

import java.util.Scanner;

/**
 *4.	Crear una aplicación en JAVA para un supermercado   se   hace   una   promoción, mediante la cual el cliente obtiene un
 * descuento dependiendo del numero de articulos que compra. Si   el   numero   comprado es   menor   que 20 el descuento es 
 * del 15% sobre el total de la compra, si es mayor o  igual  a 20 el  descuento  es  del  20%. Obtener cuánto dinero se le
 * descuenta. Y se debe de mostrar el valor obtenido al azar todos los datos deben de ser ingresados por teclado.
 * @author diego_m66h
 */
public class Tarea1Ejer4 {

    public static void main(String[] args) {
        float subtotal;
        float descuento = 0;
        float datdesc = 0;
        float total;
        int suma=1;
        int veces =-1;
        int sumando=0;
        
        Scanner dato = new Scanner( System.in);
        
        
            while ( suma >0)
            {
            System.out.print("Ingrese el costo del producto o 0 para terminar ");
            suma = (int) dato.nextFloat();
            sumando=suma+sumando;     
            veces = veces +1;    
            }    
            
            if( veces < 5 )
                    {
                    datdesc= 15; 
                    descuento = (float) (sumando*0.15); 
                    }
              
            else if( veces >= 5 )
                {
               datdesc = 20;
                descuento = (float) (sumando*0.2) ; 
            }
        
        total = sumando - descuento;
        System.out.println("SubTotal cuenta "+sumando);
        System.out.println("Cantidad de producto "+veces);
        System.out.println("Su descuento es del "+datdesc+"%");
        System.out.print("Descuento= "+descuento+"\n");
        System.out.println("Total a pagar: " + total);
        
        
        
        
        
        
    }
    
}
