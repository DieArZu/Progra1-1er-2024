/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio1;

import java.util.Scanner;


public class ValorSuper {

    public static void main(String[] args){
   
//1.	Crear una aplicación en JAVA que permita calcular el valor final a pagar en una súper tienda en donde se aplican
//los siguientes descuentos:
//a) Por compras entre 10000 y 20000 el 10%
//b) Por compras entre 20001y 50000 el 30%
//c) Por compras superiores a 50000 el 50%
//Se debe de mostrar el valor final en un printf

        float subtotal;
        float descuento = 0;
        float datdesc = 0;
        float total;
        
        Scanner dato = new Scanner( System.in);
        System.out.print("Escriba el subtotal de la compra: ");
        subtotal = dato.nextFloat();
        
        if( subtotal >= 10000 && subtotal <=20000 )
            {
               datdesc= 10; 
               descuento = (float) (subtotal*0.1); 
            }
        
        else if( subtotal >= 50000 && subtotal <20001 )
            {
               datdesc = 20;
                descuento = (float) (subtotal*0.3) ; 
            }
         else if( subtotal > 50000)
            {
                datdesc = 50; 
                descuento = (float) (subtotal*0.5); 
            }
        
        total = subtotal - descuento;
        System.out.println("Su descuento es del "+datdesc+"%");
        System.out.print("Descuento= "+descuento+"\n");
        System.out.println("Total a pagar: " + total);
       
       
       }


}