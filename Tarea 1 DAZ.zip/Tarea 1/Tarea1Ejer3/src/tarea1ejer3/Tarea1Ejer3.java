/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer3;

/**
 *3.Crear una aplicación en Java que muestre la sumatoria de todos los numeros de 0 a 1000
 * PERO SOLO LOS NUMEROS PARES ejemplo se debe de mostrar en un printf.
 * @author diego_m66h
 */
public class Tarea1Ejer3 {


    public static void main(String[] args) {
  
       int contador = 1;
        int sumando=0;
        int suma=0;
        float revpar=0;
        float sumandopar=0;
        while (contador < 10 )
        {
            sumando=sumando+1;
            suma=suma+sumando;
            contador=contador+1;
            revpar= sumando % 2;
           
            //System.out.println(revpar);
            
            if (revpar == 0) 
            {
                
                sumandopar=sumandopar+sumando;
                System.out.println(sumando+" ---> "+sumandopar);
                
                
                
           } 
            
        } 
        
       
    }
 
 }
