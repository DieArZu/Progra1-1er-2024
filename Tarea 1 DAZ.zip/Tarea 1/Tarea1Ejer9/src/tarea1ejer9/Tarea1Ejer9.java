/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer9;

import java.util.Scanner;

/**
 *9.	Crear una aplicación de JAVA que le permita al usuario ingresar dos años
 * y luego imprima todos los años en ese rango, desde luego el primer año 
 * digitado tiene que ser menor al segundo si no el programa no debe de funcionar.
 * @author diego
 */
public class Tarea1Ejer9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
        int sumando=7;
        int suma=0;
        int max=1;
        int min;
        int contador;
        
           Scanner dato = new Scanner( System.in); 
           System.out.print("Ingrese el año inferior: ");
           min = dato.nextInt();
           System.out.print("Ingrese el año superior: ");
           max = dato.nextInt();
          contador = min-1;
           
        if ( contador <= max)
           {
                while (contador < max )
                {
                 contador ++;
            System.out.println(contador);
               
        }
           }
        else if (min > max)
                     {
             System.out.println("Error en ingreso de datos");    
                     }
        
        }
        
              
        
    }
    
