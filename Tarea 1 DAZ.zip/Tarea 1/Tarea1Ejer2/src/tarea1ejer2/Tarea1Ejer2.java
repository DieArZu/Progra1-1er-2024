/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1ejer2;



public class Tarea1Ejer2 {

//2.	Crear una aplicación en Java que muestre la sumatoria de todos los numeros de 0 a 1000 se debe de mostrar en un printf.
    
    public static void main(String[] args) {
        // TODO code applicatio
              
        int contador = 1;
        int sumando=0;
        int suma=0;
        while (contador < 1001 )
        {
            sumando=sumando+1;
            suma=suma+sumando;
            contador=contador+1;
            System.out.println(sumando+" ---> "+suma);
                
    }
    }   
}
