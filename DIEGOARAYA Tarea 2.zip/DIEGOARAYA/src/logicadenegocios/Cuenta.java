
package logicadenegocios;



public class Cuenta {
    
        private int numCuenta = 0;
	private String duenio = null;
	private double saldo = 0;
    
        
public String depositar( double pMonto){
saldo += pMonto;
return "El saldo actual despúes del deposito es: "+saldo;
}
        
        
      	private boolean validarRetiro(double pMonto){
            return pMonto <=saldo;
        }
        

        public String retirar( double pMonto ) {
		if( validarRetiro(pMonto) ) {
			saldo -= pMonto;
			return "El saldo actual después del retiro es : "+ saldo;
		}
		else {
			return "No tiene suficiente dinero";
		}
	     } 

	public String toString() {
		String msg;

		msg = "Cuenta Número: " + getNumCuenta() + "\n";
		msg += "Dueño: " + getDuenio() + "\n";
		msg += "Saldo: " + getSaldo() + "\n";
		return msg;
	       }
import logicadenegocios.Cuenta;
public static void main(String[] args) {
    

    Cuenta unaCuenta = new Cuenta();
    unaCuenta.setDuenio( "Odo Smith" );
    unaCuenta.setNumCuenta( 1 );

    System.out.println( unaCuenta.depositar( 2000 ) );
    System.out.println( unaCuenta.retirar( 500 ) );
    System.out.println( unaCuenta.toString( ) );

}